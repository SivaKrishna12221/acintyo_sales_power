package ai.acintyo.ezykle.bindings;

public enum Role {
	USER, ADMIN
}
