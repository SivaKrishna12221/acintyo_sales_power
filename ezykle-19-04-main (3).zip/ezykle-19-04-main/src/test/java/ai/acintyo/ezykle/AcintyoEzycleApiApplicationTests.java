package ai.acintyo.ezykle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcintyoEzycleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
