package ai.acintyo.ezykle.model;

public record ChangePassword(String password, String repeatPassword) {
}
